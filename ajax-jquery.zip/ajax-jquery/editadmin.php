<?php 

$id=$_GET['id'];
// echo $id;exit;
$db=mysqli_connect("localhost","root","","ajith");
$result=mysqli_query($db,"SELECT * FROM users3 WHERE id='".$id."' ");
while ($row=mysqli_fetch_array($result)) {
	$first_name=$row['first_name'];
	$email=$row['email'];
	
	//$imageURL='uploads/'.$row["file_name"];
    
}?>
<!DOCTYPE html>
<html>
<head>
	<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.1.1/jquery.min.js"></script>
	<script src="///192.168.1.134/fresher_Ajith/Ajith/ajax-jquery/js/form_valid.js"></script>
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
  <Link href="css/style.css">

  </head>



  <body>
  
   
  <div>
        <form id="edit_form" method="post" action="">
          <h4 class="text-white"> edit form </h4>
            <div>
              <label>First Name:</label>
              <input type="text" id="first_name" class="left" name="first_name" value="<?php echo $first_name;?>"></input>
            </div>
            
            <div>
              <label>Email:</label>
              <input type="text" id="email" class="left" name="email" value="<?php echo $email;?>"></input>
            </div>
            
          
            <div>
              
             <input type="hidden" id="id" value=<?php echo $_GET['id'];?>> 
	           <input type="submit" name="update" class="btn-primary" value="update">
            </div>
            
        </form>
     </div>
  

</body>

</html>
