<?php
	require_once 'connect.php';
	
	$record_per_page = 3;
	
	$page = "";
	$result = "";
	
	if(ISSET($_POST['page'])){
		$page = $_POST['page'];
	}else{
		$page =  1;
	}
	
	$start = ($page - 1) * $record_per_page;
	
	$q_book = $conn->query ("SELECT * FROM `users3` LIMIT $start, $record_per_page") or die(mysqli_error());
	
	$result .="
		<table class = 'table table-bordered' >
			<thead>
				<tr>
					<th colspan = '2'><center></center></th>
				</tr>
				<tr>
					<th>id</th>
					<th>username</th>
					<th>email</th>
					
					<th>Action</>
				</tr>
			</thead>
			<tbody>
	";
	
	while($f_book = $q_book->fetch_array()){
	//echo"<pre>";print_r($f_book) ;exit;
		$imageURL = '/uploads/'.$f_book["image"];
		//echo $imageURL;exit;
		$result .= "
			 <tr>
				<td style = 'width:50%;'>".$f_book['id']."</td>
				<td style = 'width:50%;'>".$f_book['first_name']."</td>
				<td style = 'width:50%;'>".$f_book['email']."</td>
				
				<td style = 'width:50%;'><a href=editadmin.php?id=".$f_book['id'].">Edit</a>|<a href='javascript:void(0)' data-id='".$f_book['id']."' class='delete-cls'>Delete</a></td>
			
			</tr>";
	}
	$result .= "
		</tbody></table>";
	
	$q_page = $conn->query("SELECT * FROM `users3`") or die(mysqli_error());
	$v_page = $q_page->num_rows;
	$total_pages = ceil($v_page/$record_per_page);
	if ($page!=1) {
		$previous=$page-1;
		$first=1;
		$result .="<span class = 'pagination' style = 'cursor:pointer; margin:1px; padding:8px; border:1px solid #ccc;' id = '".$first."' >First</span>";
	
		$result .="<span class = 'pagination' style = 'cursor:pointer; margin:1px; padding:8px; border:1px solid #ccc;' id = '".$previous."' >Previous</span>";
		}

 	
	for($i = 1; $i <=$total_pages; $i++){
		$result .="<span class = 'pagination' style = 'cursor:pointer; margin:1px; padding:8px; border:1px solid #ccc;' id = '".$i."'>".$i."</span>";
	
	}
	if ($page!=$total_pages) {
		# code...
	
	$next=$page+1;
	$result .="<span class = 'pagination' style = 'cursor:pointer; margin:1px; padding:8px; border:1px solid #ccc;' id = '".$next."' >Next</span>";
	$last=$total_pages;
		$result .="<span class = 'pagination' style = 'cursor:pointer; margin:1px; padding:8px; border:1px solid #ccc;' id = '".$last."' >Last</span>";
	
}
	$result .="
		<span class = 'pull-right'>Page of ".$page." out of ".$total_pages."</span>
	";
	echo $result;
?>