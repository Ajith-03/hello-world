<!DOCTYPE html>
<html>

<body>
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
<Link href="css/style.css">



</body>

<form id="form1" method="post" action="">
    <label>Name</label>
    <input type="text" name="name" id="name" /><br>
    <label>password</label>
    <input type="password" name="password" id="password" /><br>
    <button type="submit" name="submit">Submit</button>
    <p >
    If you don't have any accout? <a href="index.php">SIGNUP</a>
    </p>
    <div>
    <a href="forget.php">Forget password</a></div>
</form>
<script src="https://ajax.aspnetcdn.com/ajax/jQuery/jquery-3.4.1.min.js"></script>
<script src="///192.168.1.134/fresher_Ajith/Ajith/ajax-jquery/js/login_valid.js"></script>

</html>