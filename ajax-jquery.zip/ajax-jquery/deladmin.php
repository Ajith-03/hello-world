<?php
//include_once "class/database-config.php";

$id =$_GET['id'];
$db=mysqli_connect("localhost","root","","ajith");
/*echo "<pre>";print_r($id);exit;*/
$query="DELETE FROM users3 WHERE id='$id' ";
//echo $query;exit;
$result = mysqli_query($db,$query);
if($result){
	echo " deleted successfully";
	header("Location:index1.php");
}
//ho $result;exit;

//
?>