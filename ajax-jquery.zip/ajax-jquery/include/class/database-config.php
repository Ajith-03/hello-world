<?php
session_start();
class dbconnection{
	public function connectivity(){
		$db=mysqli_connect("localhost","root","","ajith");
		if (!$db) {
			die("cannot connect to the database");
		}
		else{
			return $db;
		}
	}
}
?>