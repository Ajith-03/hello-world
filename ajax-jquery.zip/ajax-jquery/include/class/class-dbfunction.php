<?php
require_once 'database-config.php';

class dbfunction extends dbconnection
{
	function email_exists($email){
		$db=$this->connectivity();
		//$db=mysqli_connect("localhost","root","","ameen");
		$query="SELECT * FROM users3 WHERE email='".$email."'";
		// echo "<pre>";print_r($query);exit;
		$result=mysqli_query($db,$query);

		//echo "<pre>";print_r($result);exit;
		$view=mysqli_fetch_assoc($result);
		$row=mysqli_num_rows($result);
		//echo "<pre>";print_r($row);exit;
		if($row==0){
			return true;
		}
		else{
			return false;
		}
	}
	function register($first_name,$last_name,$email,$password1,$file){

		$password=md5($password1);
		$db=$this->connectivity();
		$targetDir = "../uploads/";
		

		$fileName = !empty($_FILES["file"]["name"])?basename(time().'_'.$_FILES["file"]["name"]):'';

 		$targetFilePath = $targetDir . $fileName;
		//echo $targetFilePath;exit;
 		$fileType = pathinfo($targetFilePath,PATHINFO_EXTENSION);
	   	$allowTypes = array('jpg','png','jpeg','gif','pdf',);
	   //	echo $allowTypes;exit;
		if(!empty($_FILES["file"]["name"])){
		    if(in_array($fileType,$allowTypes)){
		    	//echo $_FILES["file"]["tmp_name"];exit;
		        
		        if(move_uploaded_file($_FILES["file"]["tmp_name"], $targetFilePath)){
		           
		        }else{
		             echo "Sorry, there was an error uploading your file.";
		        }
		    }else{
		        echo 'Sorry, only JPG, JPEG, PNG, GIF, & PDF files are allowed to upload.';
		    }
		}
		
		$query="INSERT INTO users3(first_name,last_name,email,image,password) VALUES('".$first_name."','".$last_name."','".$email."','".$fileName."','".$password."')";
		
		$result=mysqli_query($db,$query);
		if($result){
			return true;
		}
		else{
			return false;
		}
	}
	function login($name,$password1){
	 
		$password=md5($password1);
		$db=$this->connectivity();
		$query="SELECT * FROM users3 WHERE first_name='".$name."' AND password='".$password."'";
		//echo $query;exit;
		$result=mysqli_query($db,$query);
		$view=mysqli_fetch_assoc($result);
		$row=mysqli_num_rows($result);
		if ($row==1) {
			
			$_SESSION['username']=$view['first_name'];
			
			return true;
		}
		else{
			return false;
		}
	}
	function forget($email){
		$db=$this->connectivity();
		$query="SELECT * FROM users3 WHERE email='".$email."'";

		$result=mysqli_query($db,$query);
		//echo"<pre>";print_r($result);exit;
		$view=mysqli_fetch_assoc($result);
		//echo"<pre>";print_r($view);exit;
		$row=mysqli_num_rows($result);
		if ($row==1) {
			return $view['email'];
		}
		else{
			return false;
		}
	}
	function password_generate($chars){ 

  		$data = '1234567890ABCDEFGHIJKLMNOPQRSTUVWXYZabcefghijklmnopqrstuvwxyz';
  		return substr(str_shuffle($data), 0, $chars);
 	}
 	function update($user,$forget){
 		$password=md5($user);
 		$db=$this->connectivity();
 		$query="UPDATE users3 SET password='".$password."' WHERE email='".$forget."'";
 		$result=mysqli_query($db,$query);
 		return true;
 	}
 	function edit($first_name,$email,$id){
		
		$db=$this->connectivity();
		//$db=mysqli_connect("localhost","root","","ameen");
		$query="UPDATE users3 SET first_name='".$first_name."',email='".$email."' WHERE id='".$id."'" ;
		//echo "<pre>";print_r($query);exit;
		$result=mysqli_query($db,$query);
		if($result){
			return true;
		}
		else{
			return false;
		}
    }
    function delete($id){
		//echo $id;exit;
		$db=$this->connectivity();
		//$db=mysqli_connect("localhost","root","","ameen");
		$query="DELETE FROM users3 WHERE id='$id'" ;
		//echo $query;exit;
		$result=mysqli_query($db,$query);
		//echo $result;exit;
		if($result){
			//echo "test";
			return true;
		}
		else{
			return false;
		}
    }
}

