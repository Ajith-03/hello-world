<?php
//echo "fjhgd";exit;
include_once "class/class-dbfunction.php";

$users3=new dbfunction();
$post=$_POST;
$files=$_FILES;
$process=$_REQUEST['process'];
 //print_r($_POST);exit;
switch ($process) {
	case 1:
		//print_r($_REQUEST);exit;
		$email=$_REQUEST['email'];
		$first_name=$_REQUEST['first_name'];
		$last_name=$_REQUEST['last_name'];
		$file=$files;
		$password=$_REQUEST['password'];
		$password1=$_REQUEST['password1'];
		$email_exists=$users3->email_exists($email);
		if ($email_exists) {
			$register=$users3->register($first_name,$last_name,$email,$password1,$file);
			if ($register) {
				$result=array('status'=>'success','message'=>'register Successfully');
				echo json_encode($result);
                
			}
			else{
				
				$result=array('status'=>'error','message'=>'registration failed');
				echo json_encode($result);
			}
		}
		else{
			
			$result=array('status'=>'error1','message'=>'email already exists');

			echo json_encode($result);
		}

		break;

    case 2;
         $name=$_POST['name'];
         $password1=$_POST['password'];
         //print_r($_POST);exit;
			$login=$users3->login($name,$password1);
			if ($login) {
				
				$result=array('status'=>'success','message'=>'login Successfully');
				echo json_encode($result);
			}
			else{
				$result=array('status'=>'error','message'=>'login failed');
				echo json_encode($result);
			}
		//echo json_encode($result);
		
		break;

	case 3;
	     $email=$_POST['email'];
	     if (!empty($email)) {
			 $forget=$users3->forget($email);
			 //echo "<pre>";print_r($forget);exit;
			if ($forget) {
				$user=$users3->password_generate(7);
				$user1=$users3->update($user,$forget);
		// if ($user1) {
		// 	echo "<script> alert('updated successfully') </alert>";
		// }
		// else{
		// 	echo "<script> alert('updated failed') </alert>";

		// }


		 require 'class/class.phpmailer.php';
                        $from       = "testermodule@gmail.com";
                        $mail       = new PHPMailer;
                        $mail->IsSMTP();            
                        $mail->IsHTML(true);
                        $mail->SMTPAuth   = true;                  
                        $mail->Host       = "smtp.gmail.com"; 
                        $mail->Port       =  587;                
                        $mail->Username   = "testermodule@gmail.com";  
                        $mail->Password   = "L!fo@123";
                        $mail->SMTPSecure = 'tls';  
                        $mail->SetFrom($from, 'admin');
                        $mail->AddReplyTo($from,'admin');
                        $mail->AddAddress($forget);
                        $mail->Subject    = 'password';
                        $mail->Body = "your alternative password is  ".$user;   
                        $mail->Send();
                         echo json_encode(array('email sent'));
                        // $status = "password Updated Successfully.";

                        // echo '<p style="color:#FF0000;">'.$status.'</p>';
                        // session_destroy();
                         //header("location:logout.php")
            		}else{

            			echo json_encode(array('Invalid email'));
            		}
        		
            }
		


		break;

	case 4;	
	  //  print_r($_POST);exit;


	     $name=$_POST['first_name'];
         $email=$_POST['email'];
         $id=$_POST['id'];
          //print_r($_POST);exit;
			$edit=$users3->edit($name,$email,$id);
			if ($edit) {
				
				$result=array('status'=>'success','message'=>'edited Successfully');
				echo json_encode($result);
			}
			else{
				$result=array('status'=>'error','message'=>' failed');
				echo json_encode($result);
			}

 	       break;

 	case 5;

 	    $id=$_POST['del_id'] ;
       //echo $id;exit;
 	    $delete=$users3->delete($id);
 	    //echo $delete;exit;
			if ($delete==1) {
				
				$result=array('status'=>'success','message'=>'deleted Successfully');
				echo json_encode($result);
			}
			else{
				$result=array('status'=>'error','message'=>' failed');
				echo json_encode($result);
			}

}
