<?php
	$conn = new mysqli("localhost", "root", "", "ajith");
	if(!$conn){
		die("Fatal Error: Connection Failed!");
	}
?>