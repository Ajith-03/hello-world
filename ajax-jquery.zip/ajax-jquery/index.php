<!DOCTYPE html>
<html>
<head>
	<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.1.1/jquery.min.js"></script>
	<script src="///192.168.1.134/fresher_Ajith/Ajith/ajax-jquery/test/js/form_valid.js"></script>
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
  <Link href="css/style.css">

  </head>
  <body>
  
   
  <div>
        <form id="first_form" method="post" enctype ="multipart/form-data" action="">
          <h4 class="text-white"> Register form </h4>
            <div>
              <label>First Name:</label>
              <input type="text" id="first_name" class="left" name="first_name"></input>
            </div>
            <div>
              <label>Last Name:</label>
              <input type="text" id="last_name" class="left"  name="last_name"></input>
            </div>
            <div>
              <label>Email:</label>
              <input type="text" id="email" class="left" name="email"></input>
            </div>
            <div>
              <label>Image:</label>
              <input type="file" id="file" class="left" name="file"></input>
            </div>
            <div>
              <label>Password:</label>
              <input type="password" id="password" class="left" name="password"></input>
            </div> 
            <div>
              <label>Confirm Password:</label>
              <input type="password" id="password1" class="left" name="password1"></input>
            </div>
            <div>
              <input type="submit" id="register" value="Register"  class="btn-primary"/>
            </div>
            <p>Already have an account? <a href="login.php">Signin</a></p>
        </form>
     </div>
  

</body>

</html>
