<?php 
session_start();
if ($_SESSION) {
	session_unset();
    session_destroy();
    //header('location:index.php');
    echo "<script> alert('Logout Successfully')</script>";
    header("refresh: 0; url=login.php");
}
 //var_dump(session_destroy());exit;

 ?>