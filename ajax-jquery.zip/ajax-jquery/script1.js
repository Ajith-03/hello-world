$(document).ready(function () {
    $("#form").validate({
        rules: {
            "name": {
                required: true,
                minlength: 2
            },
            "password": {
                required: true,
                password: true
            }
        },
        messages: {
            "name": {
                required: "Please enter a name"
            },
            "password": {
                required: "Please enter password",
                password: "password is invalid"
            }
        },
        submitHandler: function(form){
            console.log("hai")
         // for demo
            alert('valid form submitted'); // for demo
           // return false;
            window.location.href = 'index1.php';
            // for demo
        }

    });
return false;
});

