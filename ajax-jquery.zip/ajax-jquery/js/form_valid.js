$(document).ready(function() {
 
  $('#first_form').submit(function(e) {
     e.preventDefault();
    var first_name = $('#first_name').val();
    var last_name = $('#last_name').val();
    var email = $('#email').val();
    //var file_data = $("#file").prop("files")[0];
    var file=$('#file').val();
    var password = $('#password').val();
    var password1 = $('#password1').val();
    //console.log(file_data);
    
    $(".error").remove();
      clientvalid=true;
    if (first_name.length < 1) {
      $('#first_name').after('<span class="error">This field is required</span>');
       clientvalid=false;
       return false;
    }
    if (last_name.length < 1) {
      $('#last_name').after('<span class="error">This field is required</span>');
      clientvalid=false;
      return false;
    }
    if (email.length < 1) {
      $('#email').after('<span class="error">This field is required</span>');
      clientvalid=false;
      return false;
    } else {
      var regEx = /^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/;
      var validEmail = regEx.test(email);

      if (!validEmail) {
        $('#email').after('<span class="error">Enter a valid email</span>');
        clientvalid=false;
        return false;
      }
    }
    if(file.length==0){
      $('#file').after('<span class="error">pls enter the image</span>');
      clientvalid=false;
      return false;

    }
    
    if (password.length <3) {
      $('#password').after('<span class="error">enter ur password</span>');
      clientvalid=false;
      return false;
    }
    if(password1.length<3) {
      $('#password1').after('<span class="error">confirm ur password</span>');
      clientvalid=false;
      return false;
    }
    if(password!=password1) {
      $('#password1').after('<span class="error">Confirm password  is not same.</span>');
      clientvalid=false;
      return false;
    }


    if (clientvalid) {
		var file_data = $("#file").prop("files")[0];
    //return false;
    //  console.log(file_data);
		var form_data = new FormData(); 
		  form_data.append("file", file_data);
      form_data.append("first_name",first_name);
      form_data.append("last_name",last_name);
	    form_data.append("email", email);
      form_data.append("password1", password1);
      form_data.append("password", password);
	   
      $.ajax({
        type : "POST",
        url : 'include/ajax-actions.php?process=1',
		datatype:'json',
		cache: false,
		contentType: false,
		processData: false,
		data: form_data,
        success:function(res1){
        console.log(res1);
			var res4=JSON.parse(res1)
        console.log(res4);
        alert(res1.status);
        if(res1.status=='success') {            
          window.location.href = 'login.php';
        } else if(res1.status=="error1") {
			     return false;
			  } else {
          return false;
        }
      }
    })
  }
});




         //FORGET PASSWORD


$('#forget').submit(function(e) {
    e.preventDefault();
    var email1 = $('#for-email').val();
    $(".error").remove();
    valid=true;
    if (email1.length<1) {
      $('#for-email').after('<span class="error">This field is required</span>');
      valid=false;
      return false;
    } else {
      var regEx = /^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/;
      var validEmail = regEx.test(email1);

      if (!validEmail) {
        $('#for-email').after('<span class="error">Enter a valid email</span>');
        valid=false;
        return false;
      }
    }
   
      if (valid) {
        $.ajax({
          type : "POST",
          url : 'include/ajax-actions.php?process=3',
          data :{email:email1},
          success:function(res2){
            if (res2=='success') {}
              console.log(res2);
              alert(res2);
              window.location.href = 'login.php';  
          }
      })
    }




 });

});


         //EDIT OPTION
  

  
    //alert(0);
 $(document).ready(function(){
  $('#edit_form').submit(function(e) {

     e.preventDefault();
    var first_name = $('#first_name').val();
    var email = $('#email').val();
    
 
    $(".error").remove();
      clientvalid=true;
    if (first_name.length < 1) {
      $('#first_name').after('<span class="error">This field is required</span>');
       clientvalid=false;
       return false;
    }
    
    if (email.length < 1) {
      $('#email').after('<span class="error">This field is required</span>');
      clientvalid=false;
      return false;
    } else {
      var regEx = /^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/;
      var validEmail = regEx.test(email);

      if (!validEmail) {
        $('#email').after('<span class="error">Enter a valid email</span>');
        clientvalid=false;
        return false;
      }
    }
    

    if (clientvalid) {
      $.ajax({
        type : "POST",
        url : 'include/ajax-actions.php?process=4',
        data :{first_name:first_name,email:email,id:$('#id').val()},
        datatype:'json',
        success:function(res3){
          //console.log(res3);
            var res2=JSON.parse(res3);
            alert(res2.status);
            if (res2.status=="success") {
              window.location.href ='index1.php';
            }else{
              alert("ERROR");
              return false;
            }
         
        }
    })
  }
  
 });
 });
 


           //DELETE
  
 $(document).on('click','.delete-cls', function() {
    
      var page = $(this).attr('data-id');
    
      $.ajax({
        type : "POST",
        url : 'include/ajax-actions.php?process=5',
        data :{del_id:page},
        datatype:'json',
        success:function(res4){
            var res4=JSON.parse(res4);
            if (res4.status=="success") {
              window.location.href ='index1.php';
            }else{
              alert("ERROR");
              return false;
            }
          
        }
    })
  
  
 });



