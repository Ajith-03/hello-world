$(document).ready(function() {
 
  $('#form1').submit(function(e) {
     e.preventDefault();
    var name = $('#name').val();
    var password = $('#password').val();
    console.log(name);
    $(".error").remove();
      clientvalid=true;
    if (name.length < 1) {
      $('#name').after('<span class="error">This field is required</span>');
       clientvalid=false;
       return false;
    }
    
    
    if (password.length <3) {
      $('#password').after('<span class="error">enter password</span>');
      clientvalid=false;
      return false;
    }
    


    if (clientvalid) {
      $.ajax({
        type : "POST",
        url : 'include/ajax-actions.php?process=2',
        data :{name:name,password:password},
		    dataType:'json',
        success:function(res){
			        alert(res.status);
              if (res.status=='success') {
              window.location.href ='index1.php';
      		  } else {
      			  //alert("ERROR");
      			  return false;
      		  }
        }
    })
  }

  });
});


  
